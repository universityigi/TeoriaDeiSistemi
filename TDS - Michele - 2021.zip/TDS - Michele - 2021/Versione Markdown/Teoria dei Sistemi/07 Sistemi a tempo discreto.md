[toc]
## Dominio del tempo

![d4940e101a6287f5589a6735e821bff5.png](../_resources/d4940e101a6287f5589a6735e821bff5.png)

![3bded81277c40e32daff1db59b3364ef.png](../_resources/3bded81277c40e32daff1db59b3364ef.png)

> **Il problema della discretizzazione:**
> 
> A partire da un sistema a tempo continuo si vuole ottenere il sistema a tempo discreto **equivalente**, che descrive in modo approssimativo il comportamento *campionato* del sistema a tempo continuo.
> 
> Assegnato un sistema a tempo continuo, in cui gli ingressi sono costanti a tratti su intervalli della stessa ampiezza degli intervalli di campionamento, si vuole rappresentare l'evoluzione campionata dell'ingresso e dell'uscita.
> 
> Assumento il modello esplicito : $x(t)=e^{A(t-t_0)}x_o+\int_{t_0}^te^{A(t-\tau)}Bu(\tau)d\tau$
> 
> ponendo $t_0=KT, t=(K+1)T$
> 
> $x((K+1)T)=e^{AT}x(KT)+\int_{KT}^{(K+1)T}e^{A((K+1)T-\tau)}d\tau Bu(KT)$
> 
> $\to(K+1)T-\tau=\xi$
> 
> $x((K+1)T) = e^{AT}x(KT)+\int_0^Te^{A\xi}d\xi Bu(KT)$
> 
> Assumendo l'intervallo di tempo $T$ coincidente con il passo unitario del sistema discreto, allora:
> 
> $\begin{cases}x(k+1)=A_dx(k)+B_du(k)\\y(k)=C_dx(k)\end{cases}$

Esempio: Calcolare il modello discreto equivalente

Con T=2

$$
\begin{cases}
\dot{x=\begin{pmatrix}-1 &1\\0&2 \end{pmatrix}}x+\begin{pmatrix}1\\0\end{pmatrix}u
\\
y=(1\ \ 1)x+u
\end{cases}
$$

$C_d=C,\ D_d=D,\ A_d=e^{AT}=e^{2A},\ B_d=\int_0^Te^{A\xi}Bd\xi$

Calcolo gli autovalori, $\lambda_1=-1,\ \lambda_2=2$ .

Calcolo gli autovettori, $u_1=\begin{pmatrix}1\\0\end{pmatrix},\ u_2=\begin{pmatrix}1\\3\end{pmatrix}$

e la rispettiva matrice degli autovettori $v$ :

$T=\frac 1 3\begin{pmatrix}3&-1\\0&1\end{pmatrix}$

$\Phi (t)=e^{-t}\begin{pmatrix}1\\0\end{pmatrix}(1\ \ \ -\frac1 3 )+e^{2t}\begin{pmatrix}1\\3\end{pmatrix}(0\ \ \frac 1 3)$

Ora sostituisco $t\to T=2$

Ottengo $A_d=\Phi(2)=\begin{pmatrix}e^{-2}&-\frac 1 3 e^{-2}+\frac 1 3 e^4\\0&e^4\end{pmatrix}$

> **Relazioni tra autovalori a tempo continuo ed equivalenti a tempo discreto**
>
> Se $\lambda$ è un autovalore del sistema a tempo continuo, allora verrà trasformato in $\lambda \to e^{\lambda T}=\lambda_D$. 

## Dominio complesso

![2f34fbee26ad08e0a1a8b6b848e9a2fc.png](../_resources/2f34fbee26ad08e0a1a8b6b848e9a2fc.png)

![2d53ce52749a8e9cc62944da6b973d4d.png](../_resources/2d53ce52749a8e9cc62944da6b973d4d.png)

## Regime Permanente

![129e44438da107f002c60ff40076d186.png](../_resources/129e44438da107f002c60ff40076d186.png)

![266453a2a334535ddb68a550b187990d.png](../_resources/266453a2a334535ddb68a550b187990d.png)

## Stabilità

![1fd48f7ecf846e403ddff17ab73d3f30.png](../_resources/1fd48f7ecf846e403ddff17ab73d3f30.png)