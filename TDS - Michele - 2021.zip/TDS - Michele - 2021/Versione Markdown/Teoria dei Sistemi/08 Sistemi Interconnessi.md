- [Sistemi Interconnessi](#sistemi-interconnessi)
    - [Connessione in serie (o cascata)](#connessione-in-serie-o-cascata)
    - [Connessione in parallelo](#connessione-in-parallelo)
    - [Connesione in controreazione](#connesione-in-controreazione)
        - [Come si stabilizza un sistema](#come-si-stabilizza-un-sistema)
        - [Come assegno gli autovalori](#come-assegno-gli-autovalori)

# Sistemi Interconnessi

## Connessione in serie (o cascata)

```mermaid
graph LR
u --> S1
S1-->S2
S2-->y







```

**La funzione di trasferimento**: $F(s)=F_1(s)\cdot F_2(s)$

Mentre il sistema complessivo è descritto dalle equazioni:

$$
A=\begin{pmatrix}A_1&0\\B_2C_1&A_2\end{pmatrix},
B=\begin{pmatrix}B_1\\0\end{pmatrix},
C=\begin{pmatrix}0&C_2\end{pmatrix}



$$

## Connessione in parallelo

```mermaid
graph LR
u-->S1
u-->S2
S1-->+((somma))
S2-->+
+-->y








```

**La funzione di trasferimento:** $F(s)=F_1(s)+F_2(s)$

Il sistema complessivo è descritto dalle matrici:

$$
A=\begin{pmatrix}A_1&0\\0&A_2\end{pmatrix},
B=\begin{pmatrix}B_1\\B_2\end{pmatrix},
C=\begin{pmatrix}C_1&C_2\end{pmatrix}

$$

> **Considerazioni valide per entrambe le connessioni :**
> 
> Se mi ritrovo con una funzione di trasferimento in cui il grado del denominatore è minore della soma dei gradi dei denominatori delle singole funzioni di trasferimento ⇒ **c'è stata una perdita di raggiungibilità o di osservabilità**. Gli autovalori del sistema complessivo sono dati dagli autovalori dei singoli sistemi. **Infatti la dimensione del sistema è pari alla somma delle dimensioni.**
> 
> **La stabilità interna è mantenuta.**

## Connessione in controreazione

```mermaid
graph LR
u -->|somma|a((.))
a -->S1
S1-->y
S1-->S2[S2]
S2-->|sottrazione|a








```

La connesione in controazione **mi permette di andare a modificare i sistemi** (è l'unica che può farlo).

> Mi permette di modificare la stabilità di un sistema.

**La funzione di trasferimento:** $F(s)=\frac{F_1(s)}{1+F_1(s)F_2(s)}$

> Se la voglio scrivere in termini di numeratore e denominatore: $F(s)=\frac {N(s)}{D(s)+KN(s)}$ , **dove si considera F2 come un guadagno**.

Con il sistema descritto dalle matrici, considerando D = 0

$$
A=\begin{pmatrix}A_1&-B_1C_2\\B_2B_1&A_2\end{pmatrix},
B=\begin{pmatrix}B_1\\0\end{pmatrix},
C=\begin{pmatrix}C_1&0\end{pmatrix}



$$

### Come si stabilizza un sistema

Visto che con la connesione in controreazione posso cambiare gli autovalori di un sistema, posso progettare un controllore che agisce come desidero:

Prendendo come riferimento $F(s)=\frac {N(s)}{D(s)+KN(s)}$ , uso la regola di Cartesio e il criterio di Routh per determinare K. **Scelgo K, in base alla stabilità del polinomio caratteristico (denominatore di F(s))**.

Se non riesco a stabilizzare con il guadagno, allora devo progettare un controllore più complesso.

### Come assegno gli autovalori

> **Posso cambiare solo gli autovalori che sono *raggiungibili*** .

Partendo dall'ipotesi di essere in un sistema raggiungibile, io posso **assegnare gli autovalori tramite l'operazione** $A+BF$, ma come posso determinare $F$ ?

$F=-\gamma\ p^*(A)$

Dove $\gamma$ è uguale all'ultima riga della matrice R di raggiungibilità invertita ($R^{-1}$) , $p^*(A)$ è il polinomio caratteristico dove al posto di $\lambda$ ci sta $A$.

> Esempio:
> 
> Prese le matrici
> 
> ![96f6166b0a600ddd668ad47ec19e070a.png](../_resources/96f6166b0a600ddd668ad47ec19e070a.png)
> 
> Voglio realizzare un sistema asintoticamente stabile, per esempio con $\lambda_1=-1, \lambda_2=-3$.
> Quindi il polinomio che voglio assegnare sarà: $\lambda^2+4\lambda+3=(\lambda+1)(\lambda+3)$
> Adesso devo controllare che il mio sistema sia tutto raggiungibile e quindi calcolo $R$:
> <img src="../_resources/49f43ab1018e3c6a68634fa6adf6fb71.png" alt="49f43ab1018e3c6a68634fa6adf6fb71.png" width="213" height="104" class="jop-noMdConv">, che ha **rango pieno** (sistema completamente raggiungibile).
> Ora uso la formula $F=-\gamma\ p^*(A)$:
> <img src="../_resources/9068af353ba15ba3769d5e0c80394072.png" alt="9068af353ba15ba3769d5e0c80394072.png" width="413" height="82" class="jop-noMdConv">
> <img src="../_resources/da51b65b58d6d2320fe736235113e0bb.png" alt="da51b65b58d6d2320fe736235113e0bb.png" width="662" height="234" class="jop-noMdConv">
> 
> Ho trovato $F$.

Nel caso io non conosca lo stato in ogni momento, ma conosco soltanto **l'uscita dello stato**, devo ricostruirlo, tramite l'operazione $A-KC$ .

Per calcolare $K$ Faccio:

$K=p^*(A)\eta$,

dove $\eta$ è l'ultima **colonna** dell'inversa della matrice di osservabilità ($O^{-1}$).

Quindi si progetta un controllore del tipo

![c4b644c99d57a18740eae3321736841d.png](../_resources/c4b644c99d57a18740eae3321736841d.png)

> **Banda passante** in retroazione, questa è in relazione con la costante di tempo:
> $\tau=\frac 1 {\omega_n}$
> **Ricordiamo che la costante di tempo è legata all'autovalore associato con $\tau=-\frac 1 {\lambda}$**

#### Passaggi per la stabilizzazione

1.  Provo con un semplice guadagno, usando Cartesio e/o Routh.
2.  Se non funziona mi calcolo la F (e se non ho conoscenza completa dello stato anche K).
3.  Scrvo l'equazione finale del controllore.