- [Raggiungibilità e Osservabilità](#raggiungibilità-e-osservabilità)
    - [Scomposizione canonica rispetto alla raggiungibilità](#scomposizione-canonica-rispetto-alla-raggiungibilità)
    - [Scomposizione canonica rispetto alla osservabilità](#scomposizione-canonica-rispetto-alla-osservabilità)
- [Scomposizione di Kalman](#scomposizione-di-kalman)

# Raggiungibilità e Osservabilità

Qui vediamo come è possibile **decomporre** il sistema in due sottoinsiemi:

1.  Influenzato effettivamente dall'ingresso.
2.  Influenzato effettivamente dall'uscita.

![8bcd9b5e6c0f099d6c01bd612847d633.png](../_resources/8bcd9b5e6c0f099d6c01bd612847d633.png)

## Scomposizione canonica rispetto alla raggiungibilità

Uno stato $\tilde{x}$ è raggiungibile al tempo $t$ a partire dallo stato $x_0$ se $\exist$ **uno stato di tempo $t_0$ ed un ingresso $u$ che porta lo stato $x_0$ a $\tilde{x}$** .

L'insieme degli stati raggiungibili coincide con il sottospazio generato dalle colonne linearmente indipendenti della matrice $M_r= R =(B|AB|...|A^{n-1}B)$ , detta **matrice di raggiungibilità**, **se tale matrice ha rango $n$, tutti gli stati sono raggiungibili**.

**L'insieme degli stati raggiungibili, cioè il sottospazio raggiungibile, coincide con** $Im(B|AB|...|A^{n-1}B)$ = $X_r$.

<img src="../_resources/93ce5186cc66891a59c77e2412c9bfc3.png" alt="93ce5186cc66891a59c77e2412c9bfc3.png" width="458" height="161">

Esisterà quindi una matrice $T$, tale che:

<img src="../_resources/9a79572e3ead6bae723d3588b4c8147f.png" alt="9a79572e3ead6bae723d3588b4c8147f.png" width="480" height="60" class="jop-noMdConv"> Inoltre la terna A11,B1,C1 é tutta raggiungibile

dove

<img src="../_resources/81b6f00cc85b3964eb1a78cfba5789fc.png" alt="81b6f00cc85b3964eb1a78cfba5789fc.png" width="221" height="71" class="jop-noMdConv">

> Esempio:
> 
> <img src="../_resources/bab3ef55114d7253cdf2daff3f7109bd.png" alt="bab3ef55114d7253cdf2daff3f7109bd.png" width="397" height="357" class="jop-noMdConv">

## Scomposizione canonica rispetto alla osservabilità

Uno stato $\tilde{x}$ è osservabile se l'evoluzione libera a partire da quello stato è **diversa** da quella che si ottiene partendo dallo stato nullo.

Devo essere in grado di ricostruire il comportamento interno a partire dall'**osservazione in uscita.**

Un sistema è completamente osservabile $\Leftrightarrow$ Il **rango** della matrice di osservabilità è pari a $n$:

<img src="../_resources/1e0d8a7069c4d560915167e08b137240.png" alt="1e0d8a7069c4d560915167e08b137240.png" width="490" height="449">

$M_o$ $=$ $\begin{bmatrix}C\\CA\\...\\CA^{n-1}\end{bmatrix}$ .

Tramite il $ker\ M_o$ ottengo il sottospazio **inosservabile** $X_i$.

Quindi per essere completamente osservabile devo avere $ker\ M_o=0$ .

Esisterà quindi una matrice $T$, tale che:![7e09f6c8d488b7ba26bf1cc7721a4b0d.png](../_resources/7e09f6c8d488b7ba26bf1cc7721a4b0d.png)
Inoltre la terna (A11,B1,C1) e tutta osservabile.

dove

<img src="../_resources/3e4a22ac5eeda2951cdde894bc4d4597.png" alt="3e4a22ac5eeda2951cdde894bc4d4597.png" width="266" height="86" class="jop-noMdConv">

> Esempio:
> 
> <img src="../_resources/24bf60d724f28fc6b27f06ad2f6bb068.png" alt="24bf60d724f28fc6b27f06ad2f6bb068.png" width="326" height="193" class="jop-noMdConv">

> Altrimenti, considerando $M_o=[C^T|A^TC^T|A^{Tn-1}C^T]$, posso ottenere il **sottospazio osservabile** prendendo le colonne linearmente indipendenti ($Im$)

# Scomposizione di Kalman

> - $X_r$ = base costituita dalle colonne indipendenti di $M_r$
>     
> - $X_{nr}$ = sottospazio non raggiungibile = complemento ortogonale di $X_r$:![7fbee58c280e50c3521c39814364a0c4.png](../_resources/7fbee58c280e50c3521c39814364a0c4.png)
>     
> - $X_i$ = sottospazio non osservabile, kernel di $M_o$.
>     
> - $X_o$=sottospazio osservabile= complemento ortogonale di $X_i$:![bcc9a7f50dae91d4be12559a34de097f.png](../_resources/bcc9a7f50dae91d4be12559a34de097f.png)
>     

Una volta ottenuti possiamo proseguire per costruire **la matrice di trasformazione $T_k$** :

$T_k=(T_1|T_2|T_3|T_4)$

> Nell'esempio sarà una $3\times3$, ha le stesse dimensioni di $A$.

- $T_1$ , base di $X_1=X_r \cap X_i$ ![ef1b3686a75ce0aed9b8e268332c41fa.png](../_resources/ef1b3686a75ce0aed9b8e268332c41fa.png)
    
- $T_2$, base di $X_2=X_r \cap (X_{nr}+X_o)$ ![ad8fb6c2962468a2bebcc2b2f5f68b76.png](../_resources/ad8fb6c2962468a2bebcc2b2f5f68b76.png)
    
- $T_3$, base di $X3=X_i \cap (X_{nr}+X_o)$ ![1425aed8464e17f372d1bed45993fce7.png](../_resources/1425aed8464e17f372d1bed45993fce7.png)
    
- $T_4$, base di $X_4=X_{nr}\cap X_o$ ![220f959dcda5d2a2a26c5b981932b211.png](../_resources/220f959dcda5d2a2a26c5b981932b211.png)
    
    > Essendo nell'esempio una matrice $3\times 3$ mi sarei potuto anche fermare senza fare i calcoli.
    

Quindi avrò, *facendo anche l'inversa*:![788243ae089b882a1d9cbe5879792893.png](../_resources/788243ae089b882a1d9cbe5879792893.png)

> Prima di proseguire, ecco tutti gli schemi:
> 
> ![0e943ec541c6ba8b9f095698fb26d25d.png](../_resources/0e943ec541c6ba8b9f095698fb26d25d.png)

> Nell'esempio ho una $3\times 3$ quindi, non mi compare la 4 riga e la 4 colonna :
> 
> ![822a46b2dc31757befa1679b5ccb2da7.png](../_resources/822a46b2dc31757befa1679b5ccb2da7.png)

> Ricordiamo la suddivisione (**il trattino sopra vuol dire no**):
> 
> ![e2b52f63d83e729eb33c6b782b830251.png](../_resources/e2b52f63d83e729eb33c6b782b830251.png)
> 
> Sulla diagonale principale di $\hat{A}$, ho gli autovalori associati a ciascun sottoinsieme .