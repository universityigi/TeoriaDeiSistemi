- [Il regime permanente](#il-regime-permanente)
    - [é la risposta armonica del sistema](#%C3%A9-la-risposta-armonica-del-sistema)
    - [Diagrammi di Bode](#diagrammi-di-bode)
        - [Tracciamento del diagramma di Bode](#tracciamento-del-diagramma-di-bode)
            - [Tracciamento dei vari fattori](#tracciamento-dei-vari-fattori)
                - [Esempi](#esempi)
            - [Diagrammi polari o di Nyquist](#diagrammi-polari-o-di-nyquist)

# Il regime permanente

La risposta a regime permanente è la funzione del tempo alla quale tende ad **assestarsi la risposta in uscita ed è:**

- Indipendente dallo stato iniziale $x_0$.
- Dipendente dall'ingresso applicato.

> <img src="../_resources/5ed9314a89b6c3a4c9e389935e4dee53.png" alt="5ed9314a89b6c3a4c9e389935e4dee53.png" width="505" height="170" class="jop-noMdConv">

***La risposta a regime permanente è presente solo se ho stabilità asintotica.***

***Transitorio e permanente***

Quindi possiamo scomporre la risposta in uscita in **due parti, una transitoria e una permanente.** $y(t)=y_t(t)+y_r(t)$ .

> Possiamo dire che la risposta a regime è la parte persistente della risposta forzata, mentre la risposta libera è parte del transitorio.

* * *

Risposta a regime per i vari ingressi:

- Si definisce **ingresso canonico** di ordine $k$ L'ingresso: $u(t)=\frac {t^k}{k!}\delta_-1(t)$ , la cui trasformata vale: $U(s)=\frac 1{s^{k+1}}$ .

> ![28ab2acb71506af397cd1100b8588141.png](../_resources/28ab2acb71506af397cd1100b8588141.png)Quindi **il calcolo della risposta a regime permanente** si riduce al calcolo dei coefficienti $A_k$.
> 
> <img src="../_resources/1ec5307822b3090dcb7be6d862996c14.png" alt="1ec5307822b3090dcb7be6d862996c14.png" width="211" height="51">

- **La risposta a regime all'ingresso a gradino è detta risposta indicale:**
    $u(t)=\delta_{-1}(t)$, avremo, visto che le $Re(p_i)<0$ :

> > <img src="../_resources/5d31fd606ef5eeab2198aea33ffbc053.png" alt="5d31fd606ef5eeab2198aea33ffbc053.png" width="316" height="47" class="jop-noMdConv">
> > 
> > Ovvero **la riposta a regime permanete è un valore costante pari al guadagno.**
> > 
> > **![bd9ffbcc49eb14cfb9ddcb6c84e082ed.png](../_resources/bd9ffbcc49eb14cfb9ddcb6c84e082ed.png)**

- **Ingressi periodici** .

Prendendo un ingresso del tipo $sen\ \omega t$ , arriviamo tramite molti calcoli a:

> ![feba4a99024a397048de3ef5bf6fdcd8.png](../_resources/feba4a99024a397048de3ef5bf6fdcd8.png)
> 
> La risposta è dello stesso tipo dell'ingresso, ovvero periodica, con la stessa pulsazione ma con l'aggiunta di uno sfasamento e variata in ampiezza.
> 
> Sono fondamentali quindi due parametri:
> 
> - Modulo della $W(j\omega)=|W(j\omega)=M(j\omega)=\sqrt{RE^2+IM^2}$
> - Fase della $W(j\omega)=\angle W(j\omega)=\phi(\omega)=arctg\frac {IM}{RE}$
> 
> #### $W(j\omega)=W(s)|_{s=j\omega}$ é la risposta armonica del sistema
> 
> La **risposta armonica** non è una vera e propria risposta, ma serve per descrivere *come viene modificato un segnale* che transita attraverso un sistema in regime permanente.
> 
> Il valore della risposta armonica ci dice di quanto il segnale di ingresso viene modificato, inoltre visto che abbiamo posto, per segnali sinusoidali $s=j\omega$ , e quindi che $s$ abbia solo parte immaginaria, $W(j\omega)$ è dunque la funzione di trasferimento valutata lungo l'asse immaginario.
> 
> ![583682963c10020007d6adc19361c56a.png](../_resources/583682963c10020007d6adc19361c56a.png)

> **N.B**
> 
> - $W(t)=Ce^{At}B+D$, è la **matrice delle risposte impulsive**, indica la risposta di un sistema ad un ingresso impulsivo centrato in $0$.
> - $W(s)=C(sI-A)^{-1}B+D$, è la **funzione di trasferimento**, una funzione che caratterizza il comportamento di un sistema dinamico mettendo in relazione l'ingresso e l'uscita. (*andamento forzato del sistema*).
> - $W(j\omega)$ , è la **risposta armonica**, ed è la descrizione dell'uscita di un sistema dinamico mediante la frequenza invece del tempo.

## Diagrammi di Bode

Essendo la *Funzione di trasferimento* una funzione razionale, esprimibile come rapporto tra un nominatore e un denominatore, che hanno come soluzioni rispettivamente **zeri** e **poli**. Possiamo riscrivere le FT:

<img src="../_resources/44f445ff6cd2ac15dff681f56ce35d5c.png" alt="44f445ff6cd2ac15dff681f56ce35d5c.png" width="366" height="75" class="jop-noMdConv">

La **rappresentazione in forma di Bode** della funzione di trasferimento ha la seguente struttura:

<img src="../_resources/82adb0e53f9bbf5667c813575c1c9220.png" alt="82adb0e53f9bbf5667c813575c1c9220.png" width="585" height="191" class="jop-noMdConv">

Vediamo la presenza di:

- **Fattore monomio**: soluzioni in zero
    
    Quando $s-\alpha_i=s-0=j\omega |_{s=j\omega}$
    
- **Fattore binomio**: soluzioni diverse da zero
    
    ![92c7722c9e7eaa8db088df5788e27693.png](../_resources/92c7722c9e7eaa8db088df5788e27693.png)
    
- **Fattore trinomio:** soluzioni complesse
    
    ![48e6b30db3644a5281ed621b38568b3e.png](../_resources/48e6b30db3644a5281ed621b38568b3e.png)
    
- **Guadagno:**
    
    Calcolo la $W(s)$ in $s=0$, se ho poli in $s=0$ allora li annullo.
    
    * * *
    

> Esempio:

> ![b4b2025adf9fd2529080f9ae1a389909.png](../_resources/b4b2025adf9fd2529080f9ae1a389909.png)

### Tracciamento del diagramma di Bode

Un diagramma di Bode è la rappresentazione grafica della risposta armonica $W(j\omega)$ . Il grafico è composto da un piano suddiviso in due parti, con l'asse delle ascisse in scala logaritmica.

#### Tracciamento dei vari fattori

[Come tracciare i diagrammi di Bode](http://www.diag.uniroma1.it/oriolo/ca/matdid/Bode.pdf)
[Secondo pdf](http://wpage.unina.it/carcosen/FondAut_file/8.%20Diagrammi%20di%20Bode.pdf)

##### Esempi

![1e721ed81c3b20fc6bd196593b54c959.png](../_resources/1e721ed81c3b20fc6bd196593b54c959.png)

![363c96325caab3113c97c6ec28133e20.png](../_resources/363c96325caab3113c97c6ec28133e20.png)

![0218a818fb7d8d3fef9c5568709e3e18.png](../_resources/0218a818fb7d8d3fef9c5568709e3e18.png)

![7049304f2cee7fafb3fccdd901c467e1.png](../_resources/7049304f2cee7fafb3fccdd901c467e1.png)

#### Diagrammi polari o di Nyquist

<img src="../_resources/8d4bd3dcd3cb6760e2642bfd0c971afc.png" alt="8d4bd3dcd3cb6760e2642bfd0c971afc.png" width="433" height="328" class="jop-noMdConv">