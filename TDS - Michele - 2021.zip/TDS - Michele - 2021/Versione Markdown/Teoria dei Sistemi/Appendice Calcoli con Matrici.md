- [Determinante](#determinante)
- [Matrice inversa](#matrice-inversa)

### Determinante

- Matrice $2\times 2$ .

<img src="../_resources/2ce1ad22dfd8c66ae51b5371b6b40cb6.png" alt="2ce1ad22dfd8c66ae51b5371b6b40cb6.png" width="378" height="102" class="jop-noMdConv">

> Esempio:
> 
> ![9b8ad1a47de800d5715dbfde5defa6a2.png](../_resources/9b8ad1a47de800d5715dbfde5defa6a2.png)

- Matrice $3\times 3$.![83139cb0fae7e97062a78953ba91819d.png](../_resources/83139cb0fae7e97062a78953ba91819d.png)
- Matrice di ogni tipo. (metodo di Laplace)![b47a051ce5cfeab18acd7e1ce347982d.png](../_resources/b47a051ce5cfeab18acd7e1ce347982d.png)

> **Propietà del determinante:**
> 
> - Il determinante è zero se ho una colonna (o riga) tutta nulla, due colonne (o righe) sono proporzionali, una colonna (o riga) è combinazone lineare di altre.
> - Il determinante di una matrice triangolare è uguale al prodotto degli elementi sulla diagonale principale.

### Matrice inversa

> Se il determinante è zero, non posso calcolare la matrice inversa.

<img src="../_resources/a1fb529c697393ba06366049eb682442.png" alt="a1fb529c697393ba06366049eb682442.png" width="471" height="212" class="jop-noMdConv">

> Esempio
> 
> <img src="../_resources/fe9936a38ed01dfb970234cd397724c7.png" alt="fe9936a38ed01dfb970234cd397724c7.png" width="146" height="95" class="jop-noMdConv"><img src="../_resources/cbe38245ef9a1f14df528b583bba2e29.png" alt="cbe38245ef9a1f14df528b583bba2e29.png" width="183" height="50" class="jop-noMdConv">
> 
> ![540b1eca3a918754a1a02228e0e24843.png](../_resources/540b1eca3a918754a1a02228e0e24843.png)
> 
> <img src="../_resources/525ec3f1266dd27ffae7e282f2a44a7d.png" alt="525ec3f1266dd27ffae7e282f2a44a7d.png" width="340" height="231" class="jop-noMdConv">
> 
> ![9218cb30859f8db661a531d93dd9f348.png](../_resources/9218cb30859f8db661a531d93dd9f348.png)