- [Definizioni di stabilità](#definizioni-di-stabilità)
- [Condizioni di stabilità](#condizioni-di-stabilità)
- [Il criterio di Routh](#il-criterio-di-routh)
- [Stabilità esterna](#stabilità-esterna)

## Definizioni di stabilità

![277b6bcd0a9b3d5e60aa6bbe28ab9d8b.png](../_resources/277b6bcd0a9b3d5e60aa6bbe28ab9d8b.png)

Con **stabilità** si intende la proprietà di un sistema di rispondere ad eventuali perturbazioni.

Per un sistema lineare $\dot{x}(t)=A(t)x(t)+B(t)u(t)$, gli stati di equilibrio sono quelli che soddisfano l'equazione: $A(t)x_e=0$, e quindi ($x_e=0$). Cioè **l'origine dello spazio di stato è sempre uno stato di equilibrio**, esso è **unico solo se la matrice dinamica è immutabile** ($detA(t)\neq 0)$ .

## Condizioni di stabilità (interna)

Lo studio della **stabilità interna** riguarda gli effetti sul movimento dello stato provocati da perturbazioni dello stato iniziale (l'ingresso rimane costante).

- **Stabilità semplice**:
    
    Un sistema è stabile semplicemente $\Leftrightarrow$ Preso un valore $k$ finito ho che $||e^{At}||<k$ . In termini di autovalori, questo equivale a:
    
    Un sistema è stabile semplicemente se *tutti gli autovalori abbiano parte reali minore di zero, o uguale zero se con molteplicità unitaria.*
    
- **Stabilità asintotica**:
    
    Un sistema è asintoticamente stabile se è *stabile semplicemente* e $\lim_{t\to \infin}|e^{At}|=0$ , questa condizione impone che *gli autovalori siano strettamente minori di 0*.
    

> Quindi sostanzialmente lo studio della stabilità interna si riduce allo studio della stabilità dell'origine (*che implica la stabilità di tutti i modi*).

# Il criterio di Routh

Il criterio di Routh permette di analizzare la stabilità di un sistema senza il calcolo esplicito dei suoi autovalori, che per matrici di ordine $>$ 3 potrebbe diventare molto complesso.

Il criterio di Routh **si basa sulla costruzione di una tabella**.

<img src="../_resources/fa3c704b8134e409ac21faddbf83e814.png" alt="fa3c704b8134e409ac21faddbf83e814.png" width="490" height="204" class="jop-noMdConv">

> Una condizione **necessaria** affinchè il sistema sia stabile è che nel polinomio, **tutti i coefficenti abbiano lo stesso segno.**

Osservando le **variazioni di segno** dei termini sulla prima colonna possiamo conoscere il segno degli autovalori.

> **N.B** Noi non vogliamo che ci siano variazioni di segno, per avere il sistema stabile.

- Ogni variazione di segno corrisponde ad un autovalore a parte reale positiva.
    
- Ogni permanenza di segno corrisponde ad un autovalore a parte reale negativa.
    
    > Durante la costruzione della tabella potrebbero comunque verificarsi dei **casi particolari** che devono essere gestiti con opportune tecniche.
    > 
    > - **Primo elemento di una colonna pari a zero**: (questi sono 3 approcci diversi)
    >     
    >     a) Si **sostituisce** al termine nullo il simbolo $\epsilon$ a rappresentare un piccolo numero positivo.
    >     
    >     b) Si **moltiplica** il polinomio originario per un binomio con uno zero negativo: $p'(\lambda)=p(\lambda)(\lambda + 1)$ , in questo modo, ricostruendo la tabella del nuovo polinomio non avrò uno zero sulla prima colonna.
    >     
    >     c) Se la riga $p-esima$ ha i primi $h$ elementi uguali a zero, allora sostituirò alla riga $p-esima$ , una riga ottenuta **sommando** alla $p-esima$, la stessa $p-esima$ traslata a sinistra di $h$ posizioni con i posti vuoti sostituiti da zeri e cambiata di segno se $h$ è dispari.
    >     
    >     ![f59f51bcc28a6a47e3b46cffa03915cd.png](../_resources/f59f51bcc28a6a47e3b46cffa03915cd.png)
    >     
    > - **Tutti gli elementi di una riga pari a zero:**
    >     
    >     Possiamo scomporre il nostro polinomio in due polinomi $p(\lambda)=p_1(\lambda)p_2(\lambda)$ , il primo ha informazioni sulle righe precedenti a quella nulla, il secondo invece si costruisce a partire da quella immediatamente precedente a quella nulla e possiede tutte potenze pari (*si prende quel polinomio, si prendono solo i coefficenti pari e poi nel caso si deriva*), a questo punto se $p_2(\lambda)$ è semplice si procede normalmente, altrimenti si deriva il polinomio $p_2(\lambda)$ .
    >     
    

> Esempio:
> 
> ![001155699f13b372f5d50e3c3067b6ae.png](../_resources/001155699f13b372f5d50e3c3067b6ae.png)

La stabilità interna riguarda l'evoluzione libera nello stato, la **stabilità esterna** riguarda la stabilità dell'evoluzione libera in uscita.

# Stabilità esterna

La stabilità esterna è anche detta stabilità ingresso-uscita, è una proprietà che ci dice come un sistema risponde rispetto a ingressi limitati. **In generale se la risposta sarà limitata ad un ingresso limitato allora si potrà parlare si stabilità esterna.**

**![8491058230099826637ca8728c8508be.png](../_resources/8491058230099826637ca8728c8508be.png)**